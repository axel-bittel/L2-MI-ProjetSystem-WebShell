# WebShell_MI
Projet Web shell module System 2.

Ajout au sujet :
	-Un exit creer une nouvelle session.
	-Selection automatique de la boite d'insertion(par du JS).
	-Une mise en page et des couleurs de qualité inspiré des meilleurs films de science-fiction.
Limites du projet :
	-Webshell3 ne parvient pas à fermer une commande 'cat' bloquante.
	-Problème de requête avec le navigateur Safari (operationnel sur Firefox, Google Chrome, Opera, Epiphany et Microsoft Egde)